import os
import time
import subprocess
import sys

# Watchdog A monitors Watchdog B and the main Controller
# Watchdog B (not shown) would monitor Watchdog A

def is_process_running(name):
    try:
        output = subprocess.check_output(f'tasklist /FI "IMAGENAME eq {name}"', shell=True).decode()
        return name in output
    except:
        return False

def maintain_persistence():
    print("[WATCHDOG] Initializing Sprite Watchdog...")
    controller_script = "sprite_core/autonomous_controller.py"
    py_exe = r"C:\Users\viper\python\python.exe"
    
    while True:
        # Step 754: Deploy Paired Watchdog Processes
        # Check if Autonomous Controller is alive
        # For simulation, we check for a process with 'autonomous_controller.py' in cmdline
        try:
            cmd = f'wmic process where "commandline like \'%autonomous_controller.py%\'" get processid'
            output = subprocess.check_output(cmd, shell=True).decode()
            if "No Instance(s) Available" in output or not any(char.isdigit() for char in output):
                print("[WATCHDOG] Sprite Controller dead. Resuscitating...")
                subprocess.Popen([py_exe, controller_script])
        except Exception as e:
            print(f"[WATCHDOG] Error: {e}")
        
        time.sleep(30)

if __name__ == "__main__":
    maintain_persistence()
